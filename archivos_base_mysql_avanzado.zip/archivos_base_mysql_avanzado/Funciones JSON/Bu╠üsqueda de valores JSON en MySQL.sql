 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Carlos",
   "apellido": "Zambrano",
   "email": "CZambrano@kinetecoinc.com",
   "teléfono": "(619)535-4509",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Elena",
   "apellido": "Domínguez",
   "email": "EDomínguez@kinetecoinc.com",
   "teléfono": "(310)486-2672",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Luis Enrique",
   "apellido": "Vera",
   "email": "LVera@kinetecoinc.com",
   "teléfono": "(610)568-9105",
   "estado": "Pennsylvania"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Sean",
   "apellido": "Adams",
   "email": "SAdams@kinetecoinc.com",
   "teléfono": "(601)598-0726",
   "estado": "Mississippi"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Melinda",
   "apellido": "Bailey",
   "email": "MBailey@kinetecoinc.com",
   "teléfono": "(619)535-0945",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Tad",
   "apellido": "Bailey",
   "email": "TBailey@kinetecoinc.com",
   "teléfono": "(706)798-7560",
   "estado": "Georgia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Megan",
   "apellido": "Barlow",
   "email": "MBarlow@kinetecoinc.com",
   "teléfono": "(701)919-3510",
   "estado": "North Dakota"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Luis",
   "apellido": "Hernández",
   "email": "LHernández@kinetecoinc.com",
   "teléfono": "(718)545-6258",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Zeus",
   "apellido": "Baxter",
   "email": "ZBaxter@kinetecoinc.com",
   "teléfono": "(432)916-4278",
   "estado": "Texas"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Teresa",
   "apellido": "Benítez",
   "email": "TBenítez@kinetecoinc.com",
   "teléfono": "(443)237-7891",
   "estado": "Maryland"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Naida",
   "apellido": "Beard",
   "email": "NBeard@kinetecoinc.com",
   "teléfono": "(310)486-2762",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Guy",
   "apellido": "Benson",
   "email": "GBenson@kinetecoinc.com",
   "teléfono": "(214)278-2083",
   "estado": "Texas"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Julie",
   "apellido": "Blackwell",
   "email": "JBlackwell@kinetecoinc.com",
   "teléfono": "(830)761-8954",
   "estado": "Texas"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Sonia",
   "apellido": "Blanco",
   "email": "SBlanco@kinetecoinc.com",
   "teléfono": "(301)544-1527",
   "estado": "Maryland"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Andrew",
   "apellido": "Bradley",
   "email": "ABradley@kinetecoinc.com",
   "teléfono": "(609)245-2530",
   "estado": "New Jersey"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Shelley",
   "apellido": "Bradley",
   "email": "SBradley@kinetecoinc.com",
   "teléfono": "(336)157-5921",
   "estado": "North Carolina"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Lois",
   "apellido": "Brewer",
   "email": "LBrewer@kinetecoinc.com",
   "teléfono": "(775)616-9285",
   "estado": "Nevada"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Raja",
   "apellido": "Brock",
   "email": "RBrock@kinetecoinc.com",
   "teléfono": "(571)780-1122",
   "estado": "Virginia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Edan",
   "apellido": "Byers",
   "email": "EByers@kinetecoinc.com",
   "teléfono": "(865)394-8809",
   "estado": "Tennessee"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Brady",
   "apellido": "Caldwell",
   "email": "BCaldwell@kinetecoinc.com",
   "teléfono": "(515)278-1316",
   "estado": "Iowa"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Robert",
   "apellido": "Calhoun",
   "email": "RCalhoun@kinetecoinc.com",
   "teléfono": "(843)804-4895",
   "estado": "South Carolina"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Eric",
   "apellido": "Cantrell",
   "email": "ECantrell@kinetecoinc.com",
   "teléfono": "(435)589-1100",
   "estado": "Utah"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Clayton",
   "apellido": "Dillon",
   "email": "CDillon@kinetecoinc.com",
   "teléfono": "(812)476-4512",
   "estado": "Indiana"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Ernesto",
   "apellido": "García",
   "email": "EGarcía@kinetecoinc.com",
   "teléfono": "(918)635-3835",
   "estado": "Oklahoma"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Rashad",
   "apellido": "Dunn",
   "email": "RDunn@kinetecoinc.com",
   "teléfono": "(304)494-9003",
   "estado": "West Virginia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Rodrigo",
   "apellido": "Torres",
   "email": "RTorres@kinetecoinc.com",
   "teléfono": "(775)933-4613",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Roberto",
   "apellido": "Molina",
   "email": "RMolina@kinetecoinc.com",
   "teléfono": "(706)105-8153",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Nuria",
   "apellido": "Flores",
   "email": "NFlores@kinetecoinc.com",
   "teléfono": "(813)839-1187",
   "estado": "Florida"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Noelani",
   "apellido": "Fowler",
   "email": "NFowler@kinetecoinc.com",
   "teléfono": "(361)828-2151",
   "estado": "Texas"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Owen",
   "apellido": "Fox",
   "email": "OFox@kinetecoinc.com",
   "teléfono": "(561)576-8808",
   "estado": "Florida"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Ralph",
   "apellido": "Gentry",
   "email": "RGentry@kinetecoinc.com",
   "teléfono": "(952)591-5848",
   "estado": "Minnesota"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Alexa",
   "apellido": "Golden",
   "email": "AGolden@kinetecoinc.com",
   "teléfono": "(770)761-4651",
   "estado": "Georgia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Katell",
   "apellido": "Greene",
   "email": "KGreene@kinetecoinc.com",
   "teléfono": "(619)829-6331",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Bryar",
   "apellido": "Guy",
   "email": "BGuy@kinetecoinc.com",
   "teléfono": "(425)499-4340",
   "estado": "Washington"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Jada",
   "apellido": "Guy",
   "email": "JGuy@kinetecoinc.com",
   "teléfono": "(615)104-6121",
   "estado": "Tennessee"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Eden",
   "apellido": "Haley",
   "email": "EHaley@kinetecoinc.com",
   "teléfono": "(304)644-4874",
   "estado": "West Virginia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Patricia",
   "apellido": "Bermúdez",
   "email": "PBermúdez@kinetecoinc.com",
   "teléfono": "(718)545-6256",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Reese",
   "apellido": "Hayes",
   "email": "RHayes@kinetecoinc.com",
   "teléfono": "(317)835-5167",
   "estado": "Indiana"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Helen",
   "apellido": "Hays",
   "email": "HHays@kinetecoinc.com",
   "teléfono": "(405)125-9062",
   "estado": "Oklahoma"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Jason",
   "apellido": "Hemlock",
   "email": "JHemlock@kinetecoinc.com",
   "teléfono": "(916)486-2008",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Heather",
   "apellido": "Hendricks",
   "email": "HHendricks@kinetecoinc.com",
   "teléfono": "(585)299-8325",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Hu",
   "apellido": "Horne",
   "email": "HHorne@kinetecoinc.com",
   "teléfono": "(917)758-4586",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Josephine",
   "apellido": "House",
   "email": "JHouse@kinetecoinc.com",
   "teléfono": "(480)970-3846",
   "estado": "Arizona"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Yael",
   "apellido": "Jones",
   "email": "YJones@kinetecoinc.com",
   "teléfono": "(757)661-7992",
   "estado": "Virginia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Lydia",
   "apellido": "Kemp",
   "email": "LKemp@kinetecoinc.com",
   "teléfono": "(302)385-7911",
   "estado": "Delaware"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Clara ",
   "apellido": "Ortiz",
   "email": "COrtiz@kinetecoinc.com",
   "teléfono": "(732)543-3115",
   "estado": "New Jersey"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Griffith",
   "apellido": "Klein",
   "email": "GKlein@kinetecoinc.com",
   "teléfono": "(310)167-2307",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Kerry",
   "apellido": "Kramer",
   "email": "KKramer@kinetecoinc.com",
   "teléfono": "(615)294-3006",
   "estado": "Tennessee"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Hilel",
   "apellido": "Langley",
   "email": "HLangley@kinetecoinc.com",
   "teléfono": "(317)629-7121",
   "estado": "Indiana"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Ángeles",
   "apellido": "León",
   "email": "ÁLeón@kinetecoinc.com",
   "teléfono": "(612)823-4623",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Marco Antonio",
   "apellido": "Rodríguez",
   "email": "MRodríguez@kinetecoinc.com",
   "teléfono": "(909)812-7466",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Shana",
   "apellido": "Mathis",
   "email": "SMathis@kinetecoinc.com",
   "teléfono": "(205)468-0477",
   "estado": "Alabama"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Helena",
   "apellido": "Hernández",
   "email": "HHernández@kinetecoinc.com",
   "teléfono": "(937)701-0306",
   "estado": "Ohio"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Cecilia",
   "apellido": "Mccarty",
   "email": "CMccarty@kinetecoinc.com",
   "teléfono": "(434)387-0540",
   "estado": "Virginia"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Neil",
   "apellido": "Mcconnell",
   "email": "NMcconnell@kinetecoinc.com",
   "teléfono": "(973)488-1466",
   "estado": "New Jersey"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Alexander",
   "apellido": "Mccormick",
   "email": "AMccormick@kinetecoinc.com",
   "teléfono": "(518)896-1626",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Marshall",
   "apellido": "Mccoy",
   "email": "MMccoy@kinetecoinc.com",
   "teléfono": "(585)920-9686",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Christopher",
   "apellido": "Mccullough",
   "email": "CMccullough@kinetecoinc.com",
   "teléfono": "(212)451-5647",
   "estado": "New York"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Eden",
   "apellido": "Mcmillan",
   "email": "EMcmillan@kinetecoinc.com",
   "teléfono": "(205)142-6181",
   "estado": "Alabama"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "José Manuel",
   "apellido": "Mejia",
   "email": "JMejia@kinetecoinc.com",
   "teléfono": "(480)644-7570",
   "estado": "Arizona"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Hugo",
   "apellido": "Espinosa",
   "email": "HEspinosa@kinetecoinc.com",
   "teléfono": "(772)499-3880",
   "estado": "Florida"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Aretha",
   "apellido": "Montgomery",
   "email": "AMontgomery@kinetecoinc.com",
   "teléfono": "(412)402-0937",
   "estado": "Pennsylvania"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Sylvester",
   "apellido": "Mullins",
   "email": "SMullins@kinetecoinc.com",
   "teléfono": "(415)997-6874",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Melvin",
   "apellido": "Ortega",
   "email": "MOrtega@kinetecoinc.com",
   "teléfono": "(513)892-6385",
   "estado": "Ohio"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Violeta",
   "apellido": "Barrios",
   "email": "VBarrios@kinetecoinc.com",
   "teléfono": "(701)606-3258",
   "estado": "Los Angeles"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Guadalupe",
   "apellido": "Ortiz",
   "email": "GOrtiz@kinetecoinc.com",
   "teléfono": "(559)419-9790",
   "estado": "California"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Hayes",
   "apellido": "Owen",
   "email": "HOwen@kinetecoinc.com",
   "teléfono": "(952)493-2647",
   "estado": "Minnesota"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Vincent",
   "apellido": "Peterson",
   "email": "VPeterson@kinetecoinc.com",
   "teléfono": "(847)341-0471",
   "estado": "Illinois"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Quamar",
   "apellido": "Potter",
   "email": "QPotter@kinetecoinc.com",
   "teléfono": "(816)401-9673",
   "estado": "Missouri"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Dorian",
   "apellido": "Preston",
   "email": "DPreston@kinetecoinc.com",
   "teléfono": "(803)146-4350",
   "estado": "South Carolina"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Sopoline",
   "apellido": "Roberson",
   "email": "SRoberson@kinetecoinc.com",
   "teléfono": "(319)808-9280",
   "estado": "Iowa"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Nichole",
   "apellido": "Ross",
   "email": "NRoss@kinetecoinc.com",
   "teléfono": "(904)736-9207",
   "estado": "Florida"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Kellie",
   "apellido": "Rowland",
   "email": "KRowland@kinetecoinc.com",
   "teléfono": "(309)349-1288",
   "estado": "Illinois"
}');
 INSERT INTO PROVEEDOR (contacto) values ('{
   "nombre": "Desiree",
   "apellido": "Santiago",
   "email": "DSantiago@kinetecoinc.com",
   "teléfono": "(918)779-6244",
   "estado": "Oklahoma"
 }');